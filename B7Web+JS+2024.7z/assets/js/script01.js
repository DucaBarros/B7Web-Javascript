function nomeVazio() {
    if (nome == null || nome == "" || nome == "Digite nome do aluno aqui"); {
        alert("Por favor digite o nome do aluno para continuar.");
  } 
  
  do {
    var nome = prompt ("Favor informe o nome do aluno:", "Digite nome do aluno aqui")
  } while (nomeVazio() == true);