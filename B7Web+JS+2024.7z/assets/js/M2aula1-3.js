function gravity() {                                //Creating the function
    console.log('A gravidade do planeta é: ');
    console.log(9.8);
}

console.log("Hello, Hola, こんにちは");
gravity();                                         //calling the function