function fullName(name, surname) {
    console.log(`${name} ${surname}`);
}

fullName('Duca', 'Barros');
fullName('Flavia', 'Rocha');

/*
function numberSum (n1, n2) {   //Creating the function and declaring vars
    let result = (n1 + n2) * n1;
    console.log('O resultado é: ' + result);    
}   
      
numberSum (10, 15)    //calling the function attributing values
*/
