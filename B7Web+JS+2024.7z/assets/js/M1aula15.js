
let idade = 14;

/*
if (idade >= 18) {
    if (idade < 60) {
    console.log("Você é um adulto!")
    }
}

*/

//  Multiple consitions
//  &&  =   AND
//  ||  =   OR


//AND
if (idade >= 18 && idade < 60) {
    console.log("Você é um adulto!")
}

/*

//OR
if (idade >= 18 || idade < 60) {
    console.log("Você é um adulto!")
}

*/

/*

// AND + OR
if ((idade >= 18 && idade < 60) || idade < XXX ) {
    console.log("Você é um adulto!")
}

*/