/*

Creating popup alerts with JS:

alert("Hello World!")

//Declaring variables:

let nome = "Duca"                         //var string
let idade = 38                            //var number
let logado = true                           //var boolean
let lista = ["eggs, milk, wheat"]           //var array
let nomeCompleto ={nome:"Duca", idade: 38}  //var object

console.log(nome)   //show the var nome on the console

console.log(typeof lista)   //show the type of the var on the browser console

*/

/*
//1st Exercise
let nomeCarro = "Ferrari"
console.log(nomeCarro)

let precoBolo = 19.99
console.log(precoBolo)

let cidade = "São Paulo"
console.log(cidade)

*/

//Declacing Variables in the same line:

let name1 = "Duca"; let age1 = 38;
console.log(name1, age1)