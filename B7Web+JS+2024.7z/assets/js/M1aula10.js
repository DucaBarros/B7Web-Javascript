let name1 = "DUCA";
console.log(name1)

name1 = "KRATOS"
console.log(name1)

//OR

//var name1 = "DUCA";
//console.log(name1)

//name1 = "KRATOS"
//console.log(name1)


const name2 = "BARROS";
console.log(name2)
