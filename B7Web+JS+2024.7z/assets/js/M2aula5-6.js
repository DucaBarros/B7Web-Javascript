function ofAge (age) {
    if (age <= 18) {
        return true;
    } else {
        return false;
    }

}

let age = 10;
let verify = ofAge(age);

if(verify) {
    console.log('É maior de idade');
   }   else {
        console.log('É menor de idade');
    }
