let age = 14;

let isAdult = (age >= 18 && age < 60) ? 'Sim' : 'Não';

console.log(isAdult);

// ? = if  
// : = else