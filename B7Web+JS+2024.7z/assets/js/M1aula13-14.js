//IF ELSE

let idade = 14;

if (idade >= 18) {
    console.log("Voce é MAIOR de idade.");
} else {
    console.log("Você é MENOR de idade.");
}


/*

>    MAIOR QUE
<    MENOR QUE
==   IGUAL A
>=   MAIOR IGUAL A
<=    MENOR IGUAL A
!=   DIFERENTE DE
===  EXATAMENTE IGUAL A "XXX"
!==  EXATAMENTE DIFERENTE DE "XXX"   

*/


//IF ELSE com  ===

let idade2 = 20;

if (idade2 === 20) {
    idade2 = idade2 + 15;
    console.log(`Idade adicionada com sucesso = ${idade2}`);
} else {
    console.log("ERRO!");
}