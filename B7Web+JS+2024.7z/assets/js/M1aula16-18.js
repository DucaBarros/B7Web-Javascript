let idade = 25;

if (idade < 18) {
    console.log("Você é uma criança!");
}

else if (idade >= 18 && idade < 60) {
    console.log("Você é um adulto!");
}

else if (idade >= 60) {
    console.log("Você é uma idoso!");
}