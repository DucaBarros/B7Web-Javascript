//VARS
let nome = "Duca";
let sobreNome = "Barros";
let idade = 38;

//TEMPLATE STRING CONCATENATION
//let nomeCompleto = `${nome} ${sobreNome} ${idade + 5} anos`;
let nomeCompleto = `${nome} ${sobreNome} ${idade} anos`;
console.log("Nome e Idade: " + nomeCompleto);
