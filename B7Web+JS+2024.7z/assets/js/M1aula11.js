//STRING "CONCATENATION"
let nome = "Duca";
let sobreNome = "Barros";

let nomeCompleto = nome + " " + sobreNome;
console.log(nomeCompleto);

//NUMBER "SUM"
let n1 = 15;
let m2 = 35;
let n3 = 10;
let soma = (n1 + n2) - n3;

console.log(soma);




//STRING "CONCATENATION"
let nome = "Duca";
let sobreNome = "Barros";

let nomeCompleto = nome + " " + sobreNome;
console.log("Nome: " + nomeCompleto);